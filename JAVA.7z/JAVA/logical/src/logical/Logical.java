/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package logical;

/**
 *
 * @author Zishan
 */
public class Logical {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int boy, girl;
        boy = 12;
        girl = 23;
        if(boy > 19 && girl > 20){
            System.out.println("yes u can");
        }else{
            System.out.println("no u can't");
        }
    }
}
