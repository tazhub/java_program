/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package hangman;

import java.util.Scanner;
public class Hangman {
    
   

    Scanner userInput = new Scanner(System.in);
    private String keyPhrase;
    private int numberOfGuesses;
    public static String keyPhraseDashes = "_ _ _ _ _ _ ";
    String[] keyPhraseLetters = {"b", "a", "n"};
    static String userGuess = "h";
 
    String[] guessedLetters;

    public static void main(String[] args) {
        System.out.println("You have 10 attempts to guess the phrase!");
        System.out.println("Here is the phrase: " + keyPhraseDashes);
        System.out.println("Enter your guess: ");
    }
    public Hangman(String keyPhrase, int numberOfGuesses)
    {
    this.keyPhrase = "banana";
    this.numberOfGuesses = 0;
    }

     
    public String getKeyPhrase()
    {
       return this.keyPhrase;
    }
    
    public int getNumberOfGuesses()
    {
        return this.numberOfGuesses;
    }

     
    public boolean guessCharacter(char guess) throws Exception
    {
       boolean guessCharacter = false;
       for(int index = 0; index < keyPhrase.length(); index++)
            if(userInput.equals(keyPhraseLetters[index]))
                guessCharacter = true;
       for(int index = 0; index < keyPhrase.length(); index++)
            if(!userInput.equals(keyPhraseLetters[index]))
                guessCharacter = false;
       for(int index = 0; index < keyPhrase.length(); index++)
            if(userInput.equals(guessedLetters[index]))
               System.out.println("You've already guessed that letter!");
        
        if(guessCharacter)
           System.out.println("You've entered a correct letter!");
        else
           System.out.println("I'm sorry! That's incorrect.");
        return guessCharacter;         
        }
}
