
package pkgenum;

import java.util.EnumSet;
public class Enum {

  
    public static void main(String[] args) {
        for(tuna ob1: tuna.values())
        System.out.printf("%s\t%s\t%s\n", ob1, ob1.getDesc(), ob1.getAge());
        
        System.out.printf("and now the range of enum\n");
        for(tuna ob1: EnumSet.range(tuna.jabin, tuna.moon))
        System.out.printf("%s\t%s\t%s\n", ob1, ob1.getDesc(), ob1.getAge());    
    }
}
