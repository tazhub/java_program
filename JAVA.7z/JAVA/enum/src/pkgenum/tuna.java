/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package pkgenum;


public enum tuna {
    zis("strong", "24"),
    jabin("milf", "23"),
    mousumi("sexy", "21"),
    fara("cute", "17"),
    moon("chakma", "16");
    
    private final String desc;
    private final String age;
    tuna(String details, String year){
        desc = details;
        age = year;
    }
    public String getDesc(){
        return desc;
    }
    public String getAge(){
        return age;
    }
}
