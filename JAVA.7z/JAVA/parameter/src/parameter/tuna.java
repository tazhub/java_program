/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package parameter;

/**
 *
 * @author Zishan
 */
public class tuna {
    public void sampleMsg(String name){
        System.out.println("hello " +name);
    }
    
}
