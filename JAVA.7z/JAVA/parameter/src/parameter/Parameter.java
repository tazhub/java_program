/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package parameter;

import java.util.Scanner;
public class Parameter {

    public static void main(String[] args) {
       Scanner input = new Scanner(System.in);
       tuna ob1 = new tuna();
       System.out.println("enter ur name ");
       String name = input.nextLine();
       ob1.sampleMsg(name);
    }
}
