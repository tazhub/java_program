/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package eventhandling;

import javax.swing.JFrame;

public class EventHandling {

   
    public static void main(String[] args) {
        tuna ob2= new tuna();
        ob2.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        ob2.setSize(350, 100);
        ob2.setVisible(true);
      
    }
}
