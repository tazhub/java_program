/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package tostring;


public class Tuna {
    private String name;
    private pimp birthday;
    
    public Tuna(String theName, pimp theDate){
        name = theName;
        birthday = theDate;
        
    }
    public String toString(){
        return String.format("my name is %s , my bithday is %s", name, birthday);
    }
}
