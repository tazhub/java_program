/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package tostring;


public class pimp {
    private int month;
    private int day;
    private int year;
    
    public pimp(int m, int d, int y){
        month = m;
        day = d;
        year = y;
         
        System.out.printf("the constructor for this is %s\n", this );
    }
    
    public String toString(){
        return String.format("%d/%d/%d", month, day, year);
        }
    
}
