
package tostring;


public class ToString {

    
    public static void main(String[] args) {
        pimp ob1 = new pimp(4,5,6);
        Tuna ob2 = new Tuna("zis", ob1);
        System.out.println(""+ob2);
    }
}
