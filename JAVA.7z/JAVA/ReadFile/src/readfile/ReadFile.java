
package readfile;


public class ReadFile {

   
    public static void main(String[] args) {
        ReadIt ob1 = new ReadIt();
        ob1.openFile();
        ob1.readF();
        ob1.closeFile();
    }
}
