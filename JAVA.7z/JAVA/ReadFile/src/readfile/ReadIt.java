/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package readfile;

import java.io.*;
import java.util.*;
import java.lang.*;
public class ReadIt {
    private Scanner x;
    
    public void openFile(){
        try{
            x= new Scanner(new File("F:\\JAVA_WORK\\chinese.txt"));
        }
        catch(Exception e){
            System.out.println("file could not found");
        }
    }
    public void readF(){
        while(x.hasNext()){
            String a =x.next();
            String b =x.next();
            String c =x.next();
         System.out.printf("%s %s %s\n", a,b,c);   
        }
    }
    public void closeFile(){
        x.close();
    }
    
    
    
}
