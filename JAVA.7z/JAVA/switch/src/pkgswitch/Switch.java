/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package pkgswitch;


public class Switch {

    
    public static void main(String[] args) {
        int age = 5;
        switch (age){
            case 1: 
                System.out.println("u can crawl");
                break;
            case 2:
                System.out.println("u can talk");
                break;
            case 3:
                System.out.println("u can run");
                break;
            default:
                System.out.println("i dnt know ur age");
                break;
            
                
        }
     
    }
}
