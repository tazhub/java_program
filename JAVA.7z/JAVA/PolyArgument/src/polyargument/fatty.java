/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package polyargument;


public class fatty {
    public void digest(food x){
        x.eat();
    }

  
    
}
