/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package polyargument;

/**
 *
 * @author Zishan
 */
public class pie extends food{
     void eat(){
    System.out.println("this pie is great");
    }
    
}
