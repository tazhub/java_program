
package polyargument;


public class PolyArgument {

    
    public static void main(String[] args) {
        fatty ob1 = new fatty();
        food fo = new food();
        food po = new pie();
        food to = new pie();
        
            
        ob1.digest(fo);
        ob1.digest(po);
        ob1.digest(to);
   
        
        
    }
}
