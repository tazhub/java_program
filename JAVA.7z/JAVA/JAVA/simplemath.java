public class simplemath {
    int sum(int a,int b)

    {
        return(a+b);
    }

double sum(double a,double b)
    {
    return(a+b);
    }
    int factorial(int a)
    {
        int b,c=1;
        for(b=1;b<=a;b++)
        {
            c = b *c;
        }
        return c;
    }
int gcd(int a,int b)
    {
    while(a!=b)
    {
        if(a>b)
            a=a-b;
        else
        b=b-a;
    }
return a;
}
int lcm(int a,int b)
{
    int product= a*b/gcd(a, b);
return product;
}
}