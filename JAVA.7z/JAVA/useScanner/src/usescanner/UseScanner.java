/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package usescanner;

import java.util.*;
public class UseScanner {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner sc = new Scanner( System.in );
       
        String scanner = sc.nextLine();  
        System.out.println( scanner );
    }
}
