/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package arrelementcounter;

import java.util.Random;
public class ArrElementCounter {

    
    public static void main(String[] args) {
       Random r = new Random();
       int freq[]= new int[8];
       for(int a=1; a<=100000; a++){
           ++freq[1+r.nextInt(7)];
       }
       System.out.println("face\tfrequency");
       for(int face=1; face<freq.length; face++){
           System.out.println(face+"\t"+freq[face]);
       }
    }
}
