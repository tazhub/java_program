/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package pkgfinal;


public class tuna {
    private int sum;
    private final int NUMBERS;
    
    public tuna(int x){
        NUMBERS = x;
    }
    public void add(){
        sum+=NUMBERS;
    }
    public String toString(){
        return String.format("sum = %d\n", sum);
    }
    
}
