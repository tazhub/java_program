/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package pkgfinal;


public class Final {

   
    public static void main(String[] args) {
        tuna ob1 = new tuna(10);
        for(int i=0; i<5; i++){
            ob1.add();
            System.out.printf("%s", ob1);
        }
       
    }
}
