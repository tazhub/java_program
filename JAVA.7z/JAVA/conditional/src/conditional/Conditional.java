
package conditional;


public class Conditional {

   
    public static void main(String[] args) {
        int age = 21;
        System.out.println(age > 50 ? "u r old" : "u r young");
       
    }
}
