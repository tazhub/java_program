/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package mathclass;

/**
 *
 * @author Zishan
 */
public class MathClass {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
      System.out.println(""+Math.abs(-9.2));
      System.out.println(""+Math.ceil(9.2));
      System.out.println(""+Math.floor(3.4));
      System.out.println(""+Math.pow(2, 3));
      System.out.println(""+Math.sqrt(9));
    }
}
