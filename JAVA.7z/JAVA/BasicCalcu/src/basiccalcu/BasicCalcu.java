/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package basiccalcu;

import java.util.Scanner;

/**
 *
 * @author Zishan
 */
public class BasicCalcu {

   import java.util.*;
    public static void main(String[] args) {
        Scanner sc = new Scanner ( System.in );
        double fn, ln, ans;
        System.out.println("enter 1st no. ");
        fn = sc.nextDouble();
        System.out.println("enter 2nd no. ");
        ln = sc.nextDouble();
        ans = fn + ln;       
        System.out.println(""+ans);
        // TODO code application logic here
    }
}
