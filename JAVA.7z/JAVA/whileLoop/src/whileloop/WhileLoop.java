/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package whileloop;

public class WhileLoop {

    
    public static void main(String[] args) {
        int c = 10;
        while(c > 0){
            System.out.println(""+c);
            c--;
        }
        
    }
}
