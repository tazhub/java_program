
package randomnumber;

import java.util.Random;
public class RandomNumber {

   
    public static void main(String[] args) {
       Random zis = new Random();
       int c;
       for(int a=0; a<=10; a++){
           c = 1+zis.nextInt(19);
           System.out.println(c+"");
       }
       
      
           
       
    }
}
