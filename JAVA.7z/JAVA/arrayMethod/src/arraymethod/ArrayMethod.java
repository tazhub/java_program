/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package arraymethod;


public class ArrayMethod {

    
    public static void main(String[] args) {
        int zis[]={2,4,6,12,6};
        change(zis);
        for(int y:zis)
            System.out.println(""+y);
       
    }
    public static void change(int[] zis){
       for(int c=0; c< zis.length; c++ )
           zis[c]+=5;
           
            }

   
    }

