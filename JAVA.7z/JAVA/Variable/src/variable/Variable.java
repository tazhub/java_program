/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package variable;

/**
 *
 * @author Zishan
 */
public class Variable {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        double tuna;
        tuna=1.73;
        System.out.print("I want ");
        System.out.print(tuna);
        System.out.println(" no case");
        // TODO code application logic here
    }
}
