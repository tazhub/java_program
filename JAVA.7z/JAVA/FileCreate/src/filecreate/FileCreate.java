/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package filecreate;

import java.util.*;
public class FileCreate {

    
    public static void main(String[] args) {
       final Formatter x;
       
       try{
       x = new Formatter("F:\\Troll.txt");
       System.out.println("u created this");
               }
       catch(Exception e){
           System.out.println("there is no file");
       
       }
    }
}
