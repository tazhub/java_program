
package nestedif;

public class NestedIf {

    
    public static void main(String[] args) {
       int age = 60;
       if(age < 50){
           System.out.println("u r young ");
       }else{
           System.out.println("u r old");
           if(age > 70){
               System.out.println("u r too old");
           }else{
               System.out.println("u r not too old");
           }
       }
    }
}
