/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package gui;

import javax.swing.JOptionPane;
public class GUI {

    
    public static void main(String[] args) {
        String fn = JOptionPane.showInputDialog("enter first number ");
        String sn = JOptionPane.showInputDialog("enter second number ");
        
        int num1 = Integer.parseInt(fn);
        int num2 = Integer.parseInt(sn);
        int sum = num1 + num2;
        JOptionPane.showMessageDialog(null, "the sum is "+sum, "lol", JOptionPane.PLAIN_MESSAGE);
    }
}
