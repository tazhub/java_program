/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package simpleaverage;

import java.util.Scanner;
public class SimpleAverage {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int total = 0;
        int grade;
        int average;
        int counter = 0;
        
        while(counter < 10){
            grade = input.nextInt();
            total = total + grade;
            counter++;
        }
        average = total/10;
        System.out.println("ur average is "+average);
    }
}
