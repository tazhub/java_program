
package constructor;


public class Constructor {

    
    public static void main(String[] args) {
        tuna ob1 = new tuna("farah");
        tuna ob2 = new tuna("zabin");
        ob1.saying();
        ob2.saying();
   
    }
}
