
package constructor;




public class tuna {
    private String zisName;
    
    public tuna(String name){
        zisName = name;
    }
    public void setName(String name){
        zisName = name;
            
    }
    public String getName(){
        return zisName;
    }
    public void saying(){
        System.out.printf("ur first gf is %s\n", getName());
    }
    
    
}
