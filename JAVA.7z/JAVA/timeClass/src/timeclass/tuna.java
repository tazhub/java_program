
package timeclass;

public class tuna {
    private int hours=1;
    private int minutes=2;
    private int seconds=3;
    public void setTime(int h, int m, int s){
       // hours = ((h>=0 && h<24) ? h: 0);
       // minutes = ((m>=0 && m<60) ? m: 0);
       // seconds = ((s>=0 && s<60) ? s: 0);
       this.hours= 4;
       this.minutes = 4;
       this.seconds= 3;
        
    }
    public String toMilitary(){
        return String.format("%02d:%02d:%02d", hours, minutes, seconds);
    }
    public String toString(){
        return String.format("%d:%02d:%02d %s", ((hours==0 || hours==12)?12:hours%12), minutes, seconds, (hours < 12 ? "AM": "PM")  );
    }
    
    
}
