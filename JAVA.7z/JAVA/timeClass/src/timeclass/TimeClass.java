/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package timeclass;


public class TimeClass {

    
    public static void main(String[] args) {
        tuna ob1 = new tuna();
        System.out.println(""+ob1.toMilitary());
       System.out.println(""+ob1.toString());
       ob1.setTime(23, 23, 4);
        System.out.println(""+ob1.toMilitary());
       System.out.println(""+ob1.toString());
    
    }
}
