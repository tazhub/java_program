/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package hangproject;

/**
 *
 * @author Zishan
 */
public class HangProject {

     public static void main(String[] args) {
        // TODO code application logic here
        
        Hangman h = new Hangman();
        h.play();
        
    }
    
}
