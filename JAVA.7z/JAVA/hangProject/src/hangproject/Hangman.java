/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package hangproject;

/**
 *
 * @author Zishan
 */

import java.util.Scanner;

public class Hangman {
    
    private String wordList[] = {
            "brazil", "germany", "argentina", "france", "england", 
            "portugal", "italy", "spain", "uruguay", "mexico", 
            "belgium", "colombia", "netherlands", "algeria", "australia"
    };
    
    private int maxMisses = 4;
    
    public void play(){
        String randWord = wordList[(int)( Math.random() * wordList.length)];
        int len = randWord.length();
        //System.out.println(randWord + "  len=" + len);
        
        char word[] = new char[len];
        for(int i=0; i<len; i++) word[i] = '_';
        boolean flag[] = new boolean[len];
        
        char misses[] = new char[maxMisses];
        for(int i=0; i<maxMisses; i++) misses[i] = ' ';
        
        Scanner sc = new Scanner(System.in);
        int missed = 0;
        boolean match = false;
        while(missed <= maxMisses && match == false){
            System.out.println("\n-=-=-=-=-=-=-=-=-=-=-=-=-=-\n");
            
            System.out.print("Word:    ");
            for(int i=0; i<len; i++) System.out.print(word[i] + " ");
            
            System.out.print("\nMisses:  ");
            for(int i=0; i<maxMisses; i++) System.out.print(misses[i]);
            
            System.out.print("\nGuess:   ");
            char guess = sc.nextLine().charAt(0);
            //System.out.println("my guess: " + guess);
            
            boolean rightGuess = false;
            for(int i=0; i<len; i++) {
                if(randWord.charAt(i) == guess) {
                    flag[i] = true;
                    rightGuess = true;
                }
                else flag[i] = false;
            }
            //System.out.println("rightGuess = " + rightGuess);
            
            if (rightGuess) {
                for(int i=0; i<len; i++) if(flag[i]) word[i] = guess;
            }
            else {
                if(missed < 4) misses[missed] = guess;
                missed++;
            }
            //System.out.println("missed = " + missed);
            
            match = true;
            for(int i=0; i<len; i++) if(word[i] != randWord.charAt(i)) match = false;
            
            if(missed == maxMisses + 1) System.out.println("\nGAME OVER!\n");
            if (match) System.out.println("\n" + randWord + "\nYOU GOT IT!\n");
        }
        
        System.out.print("Play \"again\" or \"quit\"?  ");
        String choice = sc.nextLine();
        //System.out.println("choice = " + choice);
        
        while(!choice.equals("quit") && !choice.equals("again")){
            System.out.println("Invalid Command!");
            System.out.print("Play \"again\" or \"quit\"?  ");
            choice = sc.nextLine();
        }
        
        if(choice.equals("quit")) return;
        if(choice.equals("again")) play();
    }
            
}

