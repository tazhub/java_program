
package xceptionhandle;

import java.util.*;

public class XceptionHandle {

   
    public static void main(String[] args) {
       int x=1; 
        do{
       try{ 
        Scanner ob1 = new Scanner(System.in);
        System.out.println("enter ur 1st num = ");
        int n1 = ob1.nextInt();
        System.out.println("enter ur 1st num = ");
        int n2 = ob1.nextInt();
        int num = n1/n2;
        System.out.println("this is the ans = "+num);
        x=2;
    }
       catch(Exception e){
       System.out.println("u can't type this ");
       }
        }while(x==1);   
            
    }
    
}
