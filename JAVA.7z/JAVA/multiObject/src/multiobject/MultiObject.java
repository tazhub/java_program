
package multiobject;


public class MultiObject {

  
    public static void main(String[] args) {
        animalList ob1 = new animalList();
        dog ob2 = new dog();
        fish ob3 = new fish();
        ob1.add(ob2);
        ob1.add(ob3);
    }
}
