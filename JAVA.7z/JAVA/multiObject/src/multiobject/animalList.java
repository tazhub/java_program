/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package multiobject;


public class animalList {
     private animal[] theList = new animal[5];
    private int i = 0;
    
    public void add(animal a){
        if(i<theList.length){
        theList[i]=a;
        System.out.println("add abnother animal index "+i);
        i++;
        
        }
    }
    
}
