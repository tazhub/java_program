
package inheritance;


public class Inheritance {

    
    public static void main(String[] args) {
        tuna ob1 = new tuna();
        lol ob2 = new lol();
        
        
        ob1.eat();
        ob2.eat();
                
      
    }
}
