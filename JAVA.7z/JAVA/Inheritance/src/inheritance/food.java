/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package inheritance;


public class food {
    public void eat(){
        System.out.println("i eat burgers ");
    }
    
}
