/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package filesample;

/**
 *
 * @author Zishan
 */
import java.io.File;
public class FileSample {

    
    public static void main(String[] args) {
        
        File x = new File("c:\\test\\zishan.txt");
        
        if(x.exists())
            System.out.println(" exist!!!");
        else
            System.out.println(" this dnt exist!!!");
            
    }
    }

