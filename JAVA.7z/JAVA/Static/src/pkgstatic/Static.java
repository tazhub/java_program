/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package pkgstatic;


public class Static {

    
    public static void main(String[] args) {
      tuna ob1 = new tuna("megan", "fox");
      tuna ob2 = new tuna("kate", "winslet");
      System.out.println(tuna.getMembers());
      
    }

   }
