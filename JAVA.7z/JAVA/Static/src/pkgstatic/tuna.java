/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package pkgstatic;


public class tuna {
    private String first;
    private String second;
    private static int members = 0;
    
    public tuna(String fn, String ln){
        first = fn;
        second = ln;
        members++;
        
        System.out.printf("constructor for %s %s, members for the club %d\n", first, second, members);
    }
    public String getFirst(){
        return first;
    }
    public String getSecond(){
        return second;
    }
    public static int getMembers(){
        return members;
    }
}
