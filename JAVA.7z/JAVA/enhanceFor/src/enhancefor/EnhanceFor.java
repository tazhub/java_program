/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package enhancefor;


public class EnhanceFor {

   
    public static void main(String[] args) {
       int zis[]={23,45,6,78,5};
       int c=0;
       for(int x: zis){
           c+=x;
       }
       System.out.println(""+c);
    }
}
