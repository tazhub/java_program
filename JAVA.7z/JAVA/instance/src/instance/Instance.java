/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package instance;

import java.util.Scanner;
public class Instance {

  
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        tuna ob1 = new tuna();
        System.out.println("enter name of 1st gf here ");
        String temp = input.nextLine();
        ob1.setName(temp);
        ob1.saying();
    }
}
