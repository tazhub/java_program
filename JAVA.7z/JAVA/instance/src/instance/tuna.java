/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package instance;

import java.util.Locale;


public class tuna {
    private String zisName;
    public void setName(String name){
        zisName = name;
    }
    public String getName(){
        return zisName;
    }
    public void saying(){
        System.out.printf("your first gf is %s", getName());
    }

    
    
    
    
}
