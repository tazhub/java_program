/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package variablelengtharg;


public class VariableLengthArg {

   
    public static void main(String[] args) {
        System.out.println(""+avg(3,54,31,6,7));
       
    }
    public static int avg(int...numbers){
        int total= 0;
        for(int x:numbers)
            total+=x;
        return total/numbers.length;
    }
}
