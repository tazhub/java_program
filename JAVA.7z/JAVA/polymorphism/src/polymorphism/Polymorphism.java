
package polymorphism;


public class Polymorphism {

    
    public static void main(String[] args) {
        food ob1[] = new food[2];
        ob1[0]= new pie();
        ob1[1]= new tuna();
        
        for(int x=0;x<2;++x){
            ob1[x].eat();
        }
       
    }
}
