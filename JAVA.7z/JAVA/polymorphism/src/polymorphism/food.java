/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package polymorphism;


public class food {
    
    void eat(){
    System.out.println("this food is great");
    }
}
