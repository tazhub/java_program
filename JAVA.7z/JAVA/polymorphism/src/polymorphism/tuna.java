/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package polymorphism;

/**
 *
 * @author Zishan
 */
public class tuna extends food{
    
    void eat(){
    System.out.println("this tuna is great");
    }
}
