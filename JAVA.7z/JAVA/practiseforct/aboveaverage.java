/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package practiseforct;

/**
 *
 * @author acer
 */
import java.util.Scanner;
public class aboveaverage {
    
    
	 
	
	    public static void main(String[] args) {
	        Scanner in = new Scanner(System.in);
	        int T = in.nextInt();
	        while (T!= 0) {
	            int count = 0, N = in.nextInt(), a[] = new int[N];
	            double avg = 0;
            for (int i = 0; i < N; avg += a[i], i++)
	                a[i] = in.nextInt();
	 
	            avg = avg/N;
 
	            for (int e : a)
	                count += (e > avg) ? 1 : 0;
	 
	            double p = count;
	            p /= N;
	            System.out.format("%.3f", p * 100.00);
	            System.out.println("%");
	        }
	 
	    }
	}
    
    

