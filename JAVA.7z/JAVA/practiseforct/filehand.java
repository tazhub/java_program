/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package practiseforct;

/**
 *
 * @author acer
 */
import java.io.File;

import java.util.*;
import java.io.*;

public class filehand {
    
File fil = new File("Tall.txt");
FileReader inputFil = new FileReader(fil);
BufferedReader in = new BufferedReader(inputFil);

int [] tall = new int [100];

String s =in.readLine();

while(s!=null)
{
    int i = 0;
    tall[i] = Integer.parseInt(s); //this is line 19
    System.out.println(tall[i]);
    s = in.readLine();
}

in.close();
}
