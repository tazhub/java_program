/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package practiseforct;


import java.util.*;
public class exceptionhandle {
    public static void main (String[] args){
        
        int num1=1, num2=1;
        
        Scanner sc = new Scanner(System.in);
        System.err.print("Enter an integer");
        num1 = sc.nextInt();
        
        System.err.print("Enter another integer");
        num2 = sc.nextInt();
  //      try
    //    {
        System.out.println("\nNum1 / Num2 =" + (num1/num2));
      //  }catch(ArithmeticException e)
       // {
          //  System.out.println("You cannot divide by zero");
        //}
        //catch(InputMismatchException e)
        //{
         //   System.out.println("Enter the right data type");
        //}
  
    }
}
