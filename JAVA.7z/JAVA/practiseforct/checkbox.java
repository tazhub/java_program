/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package practiseforct;

/**
 *
 * @author acer
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class checkbox extends JFrame {

        CheckboxGroup cb1; 
        JCheckBox cb3, cb4;
        
      
    public checkbox(){
        super("Check box creation:");
        Container content = getContentPane();
        content.setLayout(new GridLayout(0,1));
        content.setBackground(Color.black);
        setSize(300,200);
        setVisible(true); 
        
        cb1 = new CheckboxGroup();
        
        
      //  content.add(new Checkbox("MATH",cb1,true));
      //  content.add(new Checkbox("ENGLISH",cb1,false));
        
        cb3 = new JCheckBox("Its JAVA");
        cb4 = new JCheckBox("Its PHP");
        
        content.add(cb3);
        content.add(cb4);
        
    }
    
    public static void main(String[] args){
        checkbox show = new checkbox();
        show.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}
