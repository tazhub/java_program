/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package practiseforct;

/**
 *
 * @author acer
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class copytext extends JFrame implements ActionListener{
    
        JTextArea textarea1, textarea2;
        JButton copybutton;
    public copytext(){
        
        super("How To Copy in JAVA");
        Container content = getContentPane();
        content.setLayout(new FlowLayout());
        // content.setBackground(Color.white);
        setSize(600,350);
        setVisible(true);
        
        String demo = "This is a demo string illustrating \n copying texts from one textArea\n to another. This is a demo string illustrating \n copying texts from one textArea\n to another. This is a demo string illustrating \n copying texts from one textArea\n to another";
        
        textarea1 = new JTextArea(demo, 17,20);
        textarea1.setEditable(true);
        
        copybutton = new JButton("Copy Now");
        copybutton.addActionListener(this);                ;
       
        textarea2 = new JTextArea(17,20);
        textarea2.setEditable(false);
        
        content.add(textarea1);
        content.add(copybutton);
        content.add(textarea2);
        
        
    }
    
    public void actionPerformed(ActionEvent e){
        textarea2.setText(textarea1.getSelectedText());
        
    }
    
    public static void main(String[] args){
        copytext show = new copytext();
        show.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}
