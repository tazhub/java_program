/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package practiseforct;

/**
 *
 * @author acer
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class temperatureconvert extends JFrame implements ActionListener{

    JTextField valueholder, resultholder;
    JButton button1,button2,button3,button4;
    
    
    public temperatureconvert(){
        super("Temperature Conversion");
        Container content = getContentPane();
        content.setLayout(new FlowLayout());
        content.setBackground(Color.white);
        setSize(500,300);
        setVisible(true);
        
        valueholder = new JTextField(10);
        valueholder.setEditable(true);
        
        resultholder = new JTextField(10);
        resultholder.setEditable(true);
        
        button1 = new JButton("Cel to Fer");
        button1.addActionListener(this);
        
        button2 = new JButton("Fer to Cel");
        button2.addActionListener(this);
        
        button3 = new JButton("Kel to Cel");
        button3.addActionListener(this);
        
        button4 = new JButton("Cel to Kel");
        button4.addActionListener(this);
        
        content.add(valueholder);
        content.add(button1);
        content.add(button2);
       content.add(button3);
        content.add(button4);
        content.add(resultholder);
        
        
    }
    
    
    
        public void actionPerformed(ActionEvent e){
           String value = valueholder.getText();
           double valued = Double.parseDouble(value);
                      
           if(e.getSource()==button1)
           {
               //resultholder.setText("Hello");
               
                  
                double result = ((9*valued)/5)+32;
                
                String resultstr = Double.toString(result);
                resultholder.setText(resultstr);
      

           }
           
           if(e.getSource()==button2)
           {
                double result = (5*(valued-32))/9;
                String resultstr = Double.toString(result);
                resultholder.setText(resultstr);
           }
           
           if(e.getSource()==button3)
           {
                double result = valued-273.15;;
                String resultstr = Double.toString(result);
                resultholder.setText(resultstr);
           }
           
           if(e.getSource()==button4)
           {
                double result = valued+273.15;
                String resultstr = Double.toString(result);
                resultholder.setText(resultstr);
           }
                
        }
    
    
    public static void main(String args[]) {
		temperatureconvert show = new temperatureconvert();
		show.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
}
