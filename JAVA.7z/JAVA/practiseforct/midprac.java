/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package practiseforct;

/**
 *
 * @author acer
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class midprac extends JFrame{
      
        
        JRadioButton rb1,rb2,rb3;
        JTextField textfield;
        ButtonGroup buttongroup;
        String demo = ("Welcome to the radio button");
        buttonaction baction;
        Container content;
        JLabel label;
        JPasswordField pass;
        JPanel panel1,panel2;
        
        
    public midprac(){
        super("Button Hide Panels");
        content = getContentPane();
        //content.setLayout(new FlowLayout());
        
        baction=new buttonaction();
        
        panel1 = new JPanel();
        panel2 = new JPanel();
       
        
        label = new JLabel("Give Your Password");
        pass=new JPasswordField();
        
        
        
        rb1 = new JRadioButton("button 1");
        rb1.addActionListener(baction);
        
        rb2 = new JRadioButton("button 2");
        rb2.addActionListener(baction);
        
        rb3 = new JRadioButton("button 3");
        rb3.addActionListener(baction);
        
        buttongroup=new ButtonGroup();
        
        buttongroup.add(rb1);
        buttongroup.add(rb2);
        buttongroup.add(rb3);
        
        
        
        textfield = new JTextField(demo,20);
        textfield.setEditable(false);
        
        panel1.add(label);
        panel1.add(pass);
        
        panel2.add(textfield);
        panel2.add(rb1);
        panel2.add(rb2);
        panel2.add(rb3);
        
        
        content.add(panel1,BorderLayout.NORTH);
        content.add(panel2,BorderLayout.SOUTH);
        
        
        
        
        
        setSize(500,500);
        setVisible(true);
        
    }
          
        
        private class buttonaction implements ActionListener{
            public void actionPerformed(ActionEvent e){
                if(e.getSource()==rb1)
                {
                    textfield.setText("1 button clicked");
                }
                else if(e.getSource()==rb2)
                {
                    textfield.setText("2 button clicked");
                }
                else if(e.getSource()==rb3)
                {
                    textfield.setText("3 button clicked");
                }
                
            }
        }
        
        
        public static void main (String[] args){
            midprac show = new midprac();
            show.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        }
        
      
    }


