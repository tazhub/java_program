/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package practiseforct;

/**
 *
 * @author acer
 */
import java.util.*;
public class linkedlist {
    public static void main(String[] args){
        String[] things = {"cat","dog","apple","hat"};
        List<String> list1 = new LinkedList<String>();
        
        for (String x: things)
            list1.add(x);
        
        String[] things2 = {"Bilai","Kutta","Apel","Tupi"};
        List<String> list2 = new LinkedList<String>();
        
        for (String y: things2)
            list2.add(y);
        
        list1.addAll(list2);
        list2 = null;
        
        
        printme(list1);
        remove(list1, 2, 6);
        printme(list1);
        reverse(list1);
        
        
    }
        
        public static void printme(List<String> l){
            for(String x: l)
            System.out.print(x+ " ");
            System.out.println();
        }
        
        public static void remove(List<String> l, int from, int to){
            l.subList(from, to).clear();
        }
        
        public static void reverse(List<String> l){
            ListIterator<String> b = l.listIterator(l.size());
            while(b.hasPrevious())
                System.out.print(b.previous()+ " ");
                System.out.println();
        }
        
        
    }
    

        