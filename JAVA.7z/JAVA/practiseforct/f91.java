/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package practiseforct;

/**
 *
 * @author acer
 */
import java.util.*;
public class f91 {
    
    public static int f91(int n){
        if(n>=101)
            return (n-10);
        return f91(f91(n+11));
    }
    
    public static void main(String[] arg){
        System.out.println(f91(500));
    }
}
