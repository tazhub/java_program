/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package practiseforct;

/**
 *
 * @author acer
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class tabs extends JFrame {
        JTabbedPane jtp;
        JPanel jp1,jp2,buttonpanel;
        JLabel label1,label2;
        JButton b1,b2,b3,b4;
        
        public tabs() {
           
        setTitle("Tabbed Pane");
        jtp = new JTabbedPane();
        getContentPane().add(jtp);
        
        buttonpanel = new JPanel();
        buttonpanel.setLayout(new GridLayout(1,4));
        
        b1 = new JButton("Button 1");
        b2 = new JButton("Button 2");
        b3 = new JButton("Button 3");
        b4 = new JButton("Button 4");
        
        buttonpanel.add(b1);
        buttonpanel.add(b2);
        buttonpanel.add(b3);
        buttonpanel.add(b4);
        
        jp1 = new JPanel();
        jp2 = new JPanel();
        
        label1 = new JLabel();
        label1.setText("This is the area of Tab1");
        
        label2 = new JLabel();
        label2.setText("This is the area of Tab2");
        
        jp1.add(buttonpanel);
        jp2.add(label2);
        
        jtp.addTab("Tab One", jp1);
        jtp.addTab("Tab two", jp2);
        
    }
    public static void main(String[] args) {
        
        tabs tp = new tabs();
        tp.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        tp.setVisible(true);
        tp.setSize(500,300);
        
    }
    
}
