/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package practiseforct;

/**
 *
 * @author acer
 */
public class arrayexception {
    public static void main (String[] srgs){
      try
        {
            int myArray[] = new int[3];
            
            for(int i=0;i<4;i++)
                System.out.println(myArray[i]);
            
        }
        
        catch (ArrayIndexOutOfBoundsException e)
        {
            System.out.println("You went too far... Better go back");
        }
    }
}
