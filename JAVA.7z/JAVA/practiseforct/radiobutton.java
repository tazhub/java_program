/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package practiseforct;

/**
 *
 * @author acer
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class radiobutton extends JFrame{
    
    
        CheckboxGroup cg;
        Label label;
    public radiobutton(){
        super("Radio Button Test");
        Container content = getContentPane();
        content.setLayout(new GridLayout(0,1));
        content.setBackground(Color.green);
        setSize(300,200);
        setVisible(true);
       
        label = new Label("What is your choice?");
        cg= new CheckboxGroup();
        
        content.add(label);
        content.add(new Checkbox("MATH", cg, false));
        content.add(new Checkbox("JAVA", cg, false));
        content.add(new Checkbox("PHP", cg, false));
        content.add(new Checkbox("ASP.NET", cg, false));
        
        
    }
    
    public static void main(String[] arg){
        radiobutton showbutton = new radiobutton();
        showbutton.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
    
}
