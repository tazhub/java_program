/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package practiseforct;

/**
 *
 * @author acer
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class jtextfieldagain extends JFrame{
     JTextField text, unedittext, textshow;
     JButton button1;
     TextHandler handler=null;
     String show;
     
    public jtextfieldagain(){
        
        super("Text Field Test");
        Container content = getContentPane();
        content.setLayout(new FlowLayout());
        content.setBackground(Color.white);
        setSize(325,180);
        setVisible(true);
        
        text = new JTextField(10);
        unedittext = new JTextField("UnEditable Text Field",20);
        unedittext.setEditable(false);
        button1 = new JButton("Action Now");
        textshow = new JTextField(20);
        textshow.setEditable(true);
        
        content.add(text);
        content.add(unedittext);
        content.add(button1);
        content.add(textshow);
        
        handler = new TextHandler();
        text.addActionListener(handler);
        unedittext.addActionListener(handler);
        button1.addActionListener(handler);
        textshow.addActionListener(handler);
        
    }
    
    private class TextHandler implements ActionListener{
        public void actionPerformed(ActionEvent e){
            if(e.getSource() == text)
            {
                show = "text:" + e.getActionCommand();
            }
            else if(e.getSource() == unedittext)
            {
                show = "unedittext:" + e.getActionCommand();
            }
            else if(e.getSource() == button1)
            {
                show = "button press:" + e.getActionCommand();
            }
            else if(e.getSource() == textshow)
            {
                show = "textshow working:" + e.getActionCommand();
            }
            
            JOptionPane.showMessageDialog(null, show);
        }
        
    }
    
    public static void main(String[] args){
        jtextfieldagain textfld = new jtextfieldagain();
        textfld.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}
