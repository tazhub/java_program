/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package practiseforct;

/**
 *
 * @author Kajol
 */
import java.util.*;
import java.io.*;

public class file3 {
    private Formatter x;
       
    public void openFile()
    {        
        try
        {
            x = new Formatter("Kajol.txt");
        }catch(Exception e){System.out.println("You have created a file.");}
        
    }
    
    public void addRecords(){
    
        x.format("%s %s %s", "Hello World", "Kajol", "File Handling");
    }
    
    public void closeFile(){
    x.close();
    }
    
    public static void main(String[] args)
    {
        file3 crtFile = new file3();
        crtFile.openFile();
        crtFile.addRecords();
        crtFile.closeFile();
    }
}
