/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package practiseforct;

/**
 *
 * @author acer
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
public class jframe extends JFrame {
    
    public static void main(String[] args){
        new jframe();
    }
    
    jframe(){
   
        JFrame hello = new JFrame();
        hello.setTitle("Its A test Program");
        hello.setVisible(true);
        hello.setSize(300, 200);
        hello.setDefaultCloseOperation(EXIT_ON_CLOSE);
        
        
        Container content = hello.getContentPane();
        content.setBackground(Color.red);
        content.setLayout(new FlowLayout());
        
        JButton button1 = new JButton("Button 1 ");
        JSlider slider1 = new JSlider(0,100,30);
        
        content.add(button1);
        content.add(slider1);
    }
    
}
