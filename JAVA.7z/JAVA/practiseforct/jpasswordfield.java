/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package practiseforct;

/**
 *
 * @author acer
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class jpasswordfield extends JFrame{

       JLabel jlbHelloWorld;
       JPasswordField password_field;
       JButton button;
       TextHandler handler = null;
       String show;
       
    public jpasswordfield(){
        
        super("Text Field Test");
        Container content = getContentPane();
        content.setLayout(new FlowLayout());
        content.setBackground(Color.white);
        setSize(325,180);
        setVisible(true);
        
        jlbHelloWorld = new JLabel("Enter Your Password");
        password_field = new JPasswordField(7);
        button = new JButton("Submit");
        
        
	content.add(jlbHelloWorld);
        content.add(password_field);
        content.add(button);
        
        handler = new TextHandler();
        button.addActionListener(handler);
        password_field.addActionListener(handler);
        
        
        
    }
    
    private class TextHandler implements ActionListener{
        public void actionPerformed(ActionEvent e){
            if(e.getSource()==password_field || e.getSource()==button)
            {
             show = "Password is Given. It is: " + e.getActionCommand();
            }
            
          
            JOptionPane.showMessageDialog(null,show);
        }
            
            
       }
        
    
    
    public static void main(String[] args){
        jpasswordfield field = new jpasswordfield();
        field.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}
