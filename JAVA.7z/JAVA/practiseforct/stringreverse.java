/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package practiseforct;

/**
 *
 * @author acer
 */

    import java.util.*;
public class stringreverse
{
	public static void main(String args[])
	{
		Scanner input = new Scanner(System.in);
		System.out.print("Enter a string: ");
		
		String s;
		s=input.nextLine();
		char arr[]=s.toCharArray();
		System.out.println("Original is :" );
		for(int i=0 ; i<arr.length ; i++)
		System.out.print(arr[i]); 
		String rev="";
		System.out.println();
		System.out.println("Length:"+ arr.length);
		for (int i=arr.length-1;i>=0;i--)
		{
			rev=rev +arr[i];
		}
	System.out.println("Reverse:\n" + rev);
	}
 }

