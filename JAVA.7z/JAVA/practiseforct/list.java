/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package practiseforct;

/**
 *
 * @author acer
 */
import java.util.*;
public class list {
    public static void main(String[] args){
        String[] things = {"cat","dog","apple","hat"};
        List<String> list1 = new ArrayList<String>();
        
        for (String x: things)
            list1.add(x);
        
        for(int i=0; i<list1.size(); i++ )
            System.out.print(list1.get(i) + " ");
            System.out.println();
            
           List<String> list2 = new ArrayList<String>();
           String[] morethings = {"Mr. Shakil","Mrs. Shakil"};
           
           for (String x: morethings)
            list2.add(x);
        
        for(int i=0; i<list2.size(); i++ )
            System.out.print(list2.get(i) + " ");
            System.out.println();
        
    }
    
    
}
