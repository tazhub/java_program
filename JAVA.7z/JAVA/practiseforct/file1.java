/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package practiseforct;

import java.io.File;
/**
 *
 * @author Kajol
 */
public class file1 {
    public static void main(String[] args)
    {
        File x = new File("D:\\kajol.txt");
            if(x.exists())
                System.out.println(x.getName() + " Exists");
            else
                System.out.println("Does not Exists");
    }
    
}
