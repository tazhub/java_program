// Java program for finding the area of a triangle from given medians and to check either the triangle is possible or not

package practiseforct;   // package name practiseforct

import java.util.*;

public class Assignment2 {    // class name "Assignment 2"
    public static void main(String[] args){
    Scanner input = new Scanner(System.in);
    double a, b, c, s, d, e;
    float area;
    int f = -1;    // to return -1 if the triangle is not possible
    
    double ma = input.nextDouble();
    double mb = input.nextDouble();
    double mc = input.nextDouble();
    
    a = (2* Math.sqrt(-(ma*ma)+ 2*(mb*mb)+ 2*(mc*mc)))/3; // its the formulla of finding 3 sides of a triangle using their medians
    b = (2* Math.sqrt(-(mb*mb)+ 2*(ma*ma)+ 2*(mc*mc)))/3;
    c = (2* Math.sqrt(-(mc*mc)+ 2*(mb*mb)+ 2*(ma*ma)))/3;

    s = (a+b+c)/2;  // this is the formulla of finding PORISIMA of a triangle
    
    area = (float)Math.sqrt(s*(s-a)*(s-b)*(s-c));  // Rules of area of a triangle using PORISIMA and 3 SIDES
    
    double  p=a+b+c;   // herep is the perimieter of the triangle
    
    
    
    if(((3*p)/4)<(ma+mb+mc)&&(ma+mb+mc)<((3*p)/2))  // condition of being triangle
    System.out.printf("%.3f", area);
    else
        System.out.printf("%d", f); 
     
   
    }
}