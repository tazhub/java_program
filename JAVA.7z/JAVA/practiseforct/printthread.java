/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package practiseforct;

/**
 *
 * @author acer
 */
public class printthread extends Thread {
    String name;
    public printthread(String n){
        name = n;
    }
    
    
    public void run(){
        for(int i=1;i<100;i++)
        {
            try
            {
                sleep(500);
                System.out.print(name);
            }
            catch(InterruptedException e){}
        }
    } 
    
    public static void main (String[] args){
        printthread t1 = new printthread("*");
        printthread t2 = new printthread("-");
        
        
        t1.start();
        t2.start();
    } 
    
}
