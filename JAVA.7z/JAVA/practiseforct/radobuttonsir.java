/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package practiseforct;

/**
 *
 * @author acer
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class radobuttonsir extends JFrame{

        JTextField textfield;
        JRadioButton one,two,three,four;
        ButtonGroup group;
        buttonwork work;
        
    public radobuttonsir(){
        super("Radio Button Easy");
        Container content = getContentPane();
        content.setLayout(new FlowLayout());
        
        textfield = new JTextField("Welcome! Choose a radio button",20);
        textfield.setEditable(false);
        
        group = new ButtonGroup();
        
        one = new JRadioButton("1");
        two = new JRadioButton("2");
        three = new JRadioButton("3");
        four = new JRadioButton("4");
        
        group.add(one);
        group.add(two);
        group.add(three);
        group.add(four);
        
        content.add(textfield);
        content.add(one);
        content.add(two);
        content.add(three);
        content.add(four);
        
        work = new buttonwork();
        
        one.addActionListener(work);
        two.addActionListener(work);
        three.addActionListener(work);
        four.addActionListener(work);
        
        setSize(500,500);
        setVisible(true);
    }
    
    private class buttonwork implements ActionListener{
        public void actionPerformed(ActionEvent e){
            Object o = e.getSource();
            if(o==one)
                textfield.setText("One is clicked");
            else if(o==two)
                textfield.setText("Two is clicked");
            else if(o==three)
                textfield.setText("Three is clicked");
            else if(o==four)
                textfield.setText("Four is clicked");
        }
    }
    
    public static void main(String[] args){
        radobuttonsir show = new radobuttonsir();
        show.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}
