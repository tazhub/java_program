/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package practiseforct;

/**
 *
 * @author acer
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class griddemo extends JFrame{
    
        JButton[] buttons;
        String[] buttonnames = {"one","two","three","four","five","six"};
        boolean toogle = true;
        buttonaction baction;
        GridLayout grid1,grid2;
        Container content;
    public griddemo(){
        
        super("Grid Style View");
        content = getContentPane();
        
        grid1 = new GridLayout(3,2);
        grid2 = new GridLayout(2,3);
        
        buttons = new JButton[buttonnames.length];
        baction = new buttonaction();
        
        for(int count=0; count<buttonnames.length; count++)
        {
            buttons[count] = new JButton(buttonnames[count]);
            buttons[count].addActionListener(baction);
            content.add(buttons[count]);
            
        }
        
        
        
        
        setLayout(grid1);
        setSize(500,500);
        setVisible(true);
        
        
    }
    
    private class buttonaction implements ActionListener{
        public void actionPerformed(ActionEvent e){
            if(toogle)
                content.setLayout(grid2);
            else
                content.setLayout(grid1);
            toogle = !toogle;
            content.validate();
        }
    }
    
    public static void main(String[] args){
        griddemo show = new griddemo();
        show.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                
    }
}
