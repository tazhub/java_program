/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package practiseforct;

/**
 *
 * @author acer
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class threepanel extends JFrame{

        JPanel sliderpanel,buttonpanel,radiopanel,checkpanel,textareapanel;
        JButton button1,button2,button3,copybutton;
        JRadioButton rb1,rb2,rb3,rb4;
        JCheckBox cb1,cb2,cb3,cb4;
        JSlider slider1, slider2, slider3;
        ButtonGroup buttongroup;
        JTextArea textarea1,textarea2;
        String demo = "Its a simple testing issue. Its a simple testing issue. Its a simple testing issue. Its a simple testing issue. Its a simple testing issue. Check it its copying or not. Enjoy!!";
        ButtonAct baction;
        
    public threepanel(){
        
        super("Three Panel Test");
        
        sliderpanel = new JPanel();
        buttonpanel = new JPanel();
        radiopanel = new JPanel();
        checkpanel = new JPanel();
        textareapanel = new JPanel();
        
        button1 = new JButton("Button1");
        button2 = new JButton("Button2");
        button3 = new JButton("Button3");
        
        rb1 = new JRadioButton("1st Button");
        rb2 = new JRadioButton("2nd Button");
        rb3 = new JRadioButton("3rd Button");
        rb4 = new JRadioButton("4th Button");
        
        cb1 = new JCheckBox("1st CheckBox");
        cb2 = new JCheckBox("2nd CheckBox");
        cb3 = new JCheckBox("3rd CheckBox");
        cb4 = new JCheckBox("4th CheckBox");
               
        
        checkpanel.add(cb1);
        checkpanel.add(cb2);
        checkpanel.add(cb3);
        checkpanel.add(cb4);
        
        
        buttongroup = new ButtonGroup();
        
        buttongroup.add(rb1);
        buttongroup.add(rb2);
        buttongroup.add(rb3);
        buttongroup.add(rb4);
        
        slider1 = new JSlider(0,100,30);
        slider2 = new JSlider(0,100,60);
        slider3 = new JSlider(0,100,80);
        
        sliderpanel.setLayout(new GridLayout(3,1));
        buttonpanel.setLayout(new GridLayout(1,3));
        radiopanel.setLayout(new GridLayout(1,4));
        checkpanel.setLayout(new GridLayout(4,1));
        textareapanel.setLayout(new GridLayout(3,1));
        
        sliderpanel.add(slider1);
        sliderpanel.add(slider2);
        sliderpanel.add(slider3);
        
        buttonpanel.add(button1);
        buttonpanel.add(button2);
        buttonpanel.add(button3);
        
        radiopanel.add(rb1);
        radiopanel.add(rb2);
        radiopanel.add(rb3);
        radiopanel.add(rb4);
        
        textarea1 = new JTextArea(demo,17,20);
        textarea1.setEditable(true);
        copybutton = new JButton("Copy Now");
        baction = new ButtonAct();
        copybutton.addActionListener(baction);
        textarea2 = new JTextArea (17,20);
        textarea2.setEditable(false);
        
        
        textareapanel.add(textarea1);
        textareapanel.add(copybutton);
        textareapanel.add(textarea2);
        
        

        
        add(sliderpanel,BorderLayout.EAST);
        add(buttonpanel,BorderLayout.NORTH);
        add(radiopanel,BorderLayout.SOUTH);
        add(checkpanel,BorderLayout.WEST);
        add(textareapanel,BorderLayout.CENTER);
        
        setSize(640,480);
        setVisible(true);
        
        
    }
    
    private class ButtonAct implements ActionListener{
        public void actionPerformed(ActionEvent e){
                  if(e.getSource()==copybutton)
                  {
                      textarea2.setText(textarea1.getSelectedText());
                  }
        }
    }
    
    public static void main(String[] args){
        threepanel show = new threepanel();
        show.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}
