/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package practiseforct;

/**
 *
 * @author Kajol
 */
import java.util.*;

public class file2 {
    public static void main(String[] args)
    {
        final Formatter x;
        
        try
        {
            x = new Formatter("kajol.txt");
            System.out.println("You have created a file.");
        }
        catch(Exception e)
        {
        
            System.out.println("Error!!");
        }
    }
    
}
