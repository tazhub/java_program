/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package practiseforct;

/**
 *
 * @author acer
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class paneldemo extends JFrame{
    
    
        private JButton[] buttons;
        private JPanel buttonpanel1,buttonpanel2,buttonpanel3,buttonpanel4;
    public paneldemo(){
        
        super ("Panel Demo Looks");
        
        
        buttonpanel1 = new JPanel();
        buttonpanel2 = new JPanel();
        buttonpanel3 = new JPanel();
        buttonpanel4 = new JPanel();
        
        buttons = new JButton[5];
        buttonpanel1.setLayout(new GridLayout());
         buttonpanel2.setLayout(new GridLayout());
          buttonpanel3.setLayout(new GridLayout());
           buttonpanel4.setLayout(new GridLayout());
          
        
        
        for(int count=0; count<buttons.length; count++)
        {
            buttons[count] = new JButton("ButtonP1"+ (count+1));
            buttonpanel1.add(buttons[count]);
        }
        for(int count=0; count<buttons.length; count++)
        {
            buttons[count] = new JButton("ButtonP2"+ (count+1));
            buttonpanel2.add(buttons[count]);
        }
        for(int count=0; count<buttons.length; count++)
        {
            buttons[count] = new JButton("ButtonP3"+ (count+1));
            buttonpanel3.add(buttons[count]);
        }
        
        
        add(buttonpanel1,BorderLayout.NORTH);
        add(buttonpanel2,BorderLayout.SOUTH);
        
        
        
        
        
        
        
    }
    
    public static void main(String[] args){
        paneldemo show = new paneldemo();
        show.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        show.setSize(500,500);
        show.setVisible(true);
    }
}
