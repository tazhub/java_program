/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package practiseforct;

/**
 *
 * @author acer
 */
public class stringtest {
    public static void main(String[] args){ //main function works here
        String str1 = new String("Hello"); //New object created for first string
        String str2 = new String("hello"); //New object created for second string
        System.out.println(str2.concat(str1)); //
        System.out.println(str2.charAt(0));
        System.out.println(str1.compareTo(str2));
        System.out.println(str1.compareToIgnoreCase(str2));//
        
        
    }
}
