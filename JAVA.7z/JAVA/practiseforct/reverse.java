/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package practiseforct;

/**
 *
 * @author acer
 */
import java.util.*;
public class reverse {
    
    public static void main(String[] args){
        String sentence;
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter a sentence");
        sentence = sc.nextLine();
        
        String[] tokens = sentence.split(" ");
        System.out.println("Number of tokens: " + tokens.length);
        
        for(int i=0; i<tokens.length;i++)
            System.out.println(tokens[i]);
    }
    
}
