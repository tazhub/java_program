/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package practiseforct;

/**
 *
 * @author acer
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
public class menutest extends JFrame {
        
        JMenu filemenu,formatmenu,colormenu;
        JMenuItem aboutitem,exititem;
        JMenuBar bar;
        buttonaction baction;
        
        public menutest() {
        super("Menu Test Only");
        filemenu = new JMenu("File");
        filemenu.setMnemonic('e');
        
        aboutitem = new JMenuItem("About",50);
        aboutitem.setMnemonic('A');
        filemenu.add(aboutitem);
        aboutitem.addActionListener(baction);
        
        exititem = new JMenuItem("exit");
        exititem.setMnemonic('x');
        
        filemenu.add(exititem);
        exititem.addActionListener(baction);
        
        bar = new JMenuBar();
        setJMenuBar(bar);
        bar.add(filemenu);
        
        formatmenu = new JMenu("Format");
        formatmenu.setMnemonic('t');
        bar.add(formatmenu);
        
    }
        
    private class buttonaction implements ActionListener{
    
        public void actionPerformed(ActionEvent e){
            Object o = e.getSource();
            if(o==aboutitem)
            {
                JOptionPane.showMessageDialog(null, "this is an example");
            }
            else if(o==exititem)
            {
                System.exit(1);
            }
        }
    }
    
    
    public static void main(String[] args) {
        
        menutest tp = new menutest();
        tp.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        tp.setVisible(true);
        
    }
        
   
    
    
}
