/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package practiseforct;

/**
 *
 * @author acer
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class buttonhide extends JFrame{

        JButton[] buttons;
        String[] buttonnames = {"Hide North","Hide South","Hide East","Hide West","Hide Center"};
        buttonaction baction;
    public buttonhide(){
    
        super("Button Hide Test");
        Container content = getContentPane();
        content.setLayout(new BorderLayout(5,5));
        content.setBackground(Color.white);
        setSize(500,300);
        setVisible(true);
        
        baction = new buttonaction();
        
        buttons = new JButton[buttonnames.length];
        
        for(int count=0;count<buttonnames.length;count++)
        {
            buttons[count] = new JButton(buttonnames[count]);
            buttons[count].addActionListener(baction);
        }
        
        
        content.add(buttons[0],BorderLayout.NORTH);
        content.add(buttons[1],BorderLayout.SOUTH);
        content.add(buttons[2],BorderLayout.EAST);
        content.add(buttons[3],BorderLayout.WEST);
        content.add(buttons[4],BorderLayout.CENTER);
        
        
        
    }
    
    private class buttonaction implements ActionListener{
        public void actionPerformed(ActionEvent e){
           for(JButton button: buttons)
           {
            if(e.getSource() == button)
           {
                button.setVisible(false);
            }
            else
                button.setVisible(true);
           }
           
                
        }
    }
    
    public static void main (String[] args){
        buttonhide show = new buttonhide();
        show.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}
