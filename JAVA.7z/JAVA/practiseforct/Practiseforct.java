/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package practiseforct;

/**
 *
 * @author acer
 */
import javax.swing.*;
public class Practiseforct extends JFrame {

   public static void main(String[] args){
       new Practiseforct();
   }
   
   Practiseforct(){
       super("Hello World");
       JPanel jhelloworld = new JPanel();
       add (jhelloworld);
       this.setSize(300,300);
       setVisible(true);
       setDefaultCloseOperation(EXIT_ON_CLOSE);
   }
    

}
