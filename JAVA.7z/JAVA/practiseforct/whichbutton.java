/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package practiseforct;

/**
 *
 * @author acer
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class whichbutton extends JFrame {
    
        JButton button1, button2;
        JTextField input;
        
    public whichbutton(){
        
        super("Which Button Select?");
        Container content = getContentPane();
        content.setLayout(new FlowLayout());
        content.setBackground(Color.blue);
        setSize(300,200);
        setVisible(true);
        
        button1 = new JButton("Button 1");
        button2 = new JButton("Button 2");
        input = new JTextField(20);
   
        
        content.add(input);
        content.add(button1);
        content.add(button2);
    }
    
    
    public static void main(String[] args){
        whichbutton show = new whichbutton();
        show.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}
