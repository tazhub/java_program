/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package practiseforct;

/**
 *
 * @author Kajol
 */
import java.util.*;
import java.io.*;

public class file4 {
    
    private Scanner sc;
    
    public void openFile()
    {
        try
        {
            sc = new Scanner(new File("Kajol.txt"));
        }
        catch(Exception e)
        {
            System.out.printf("Could not find");
        
        }
    }
        public void readFile()
        {
            /*while(sc.hasNext())
            {
                String a = sc.next();
                String b = sc.next();
                String c = sc.next();
                
                System.out.printf("%s %s %s\n",a,b,c);
            }*/
            
            while(sc.hasNextLine())
                
                System.out.printf(sc.nextLine());
                
        }
        
        public void closeFile()
        {
            sc.close();
        }
        
        public static void main(String[] args)
    {
        file4 r = new file4();
        r.openFile();
        r.readFile();
        r.closeFile();
    }
        
    }
    
   
