/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package array;


public class Array {

   
    public static void main(String[] args) {
        int zis[]= new int[4];
        int zog[]={0,1,2,4};
        zis[0]=2;
        zis[1]=5;
        zis[2]=4;
        zis[3]=6;
        System.out.println(""+zis[0]);
        System.out.println(""+zog[3]);
    }
}
