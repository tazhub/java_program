/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package incrementop;

import java.util.Scanner;
public class IncrementOp {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner sc = new Scanner( System.in );
        
       int tuna=5;
       int chodna=6;
       int lol=2;
       lol += 3;
       ++chodna;
       --tuna;
       System.out.println(""+tuna);
       System.out.println(""+chodna);
       System.out.println(""+lol);
    }
}
