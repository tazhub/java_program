/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package multiconstructor;


public class MultiConstructor {
    
   
    public static void main(String[] args) {
     
     tuna ob1 = new tuna();
     tuna ob2 = new tuna(5);
     tuna ob3 = new tuna(5,3);
     tuna ob4 = new tuna(5,3,2);
     
     System.out.printf("%s\n", ob1.toMilitar() );
     System.out.printf("%s\n", ob2.toMilitar() );
     System.out.printf("%s\n", ob3.toMilitar() );
     System.out.printf("%s\n", ob4.toMilitar() );
    }
}
