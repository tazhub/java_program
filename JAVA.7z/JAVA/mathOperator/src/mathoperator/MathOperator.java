/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package mathoperator;


import java.util.Scanner;
public class MathOperator {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner sc = new Scanner( System.in );
        int fuck,suck,luck;
        fuck = 3;
        suck = 8;
        luck = fuck + suck;
        System.out.println(""+luck);
    }
}
