/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package overloading;


public class Adding {
    
    public int add(int x, int y){
        return x+y;
    }
    public int add(int x, int y, int z){
        return add(add(x,y),z);
    }
    public double add(double x, double y){
        return x+y;
    }
   
}
