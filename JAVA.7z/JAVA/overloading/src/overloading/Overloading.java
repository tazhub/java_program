
package overloading;


public class Overloading {

   
    public static void main(String[] args) {
        Adding ob1 = new Adding();
        System.out.println("result for first 1: "+ob1.add(4, 5));
        System.out.println("result for second 2: "+ob1.add(3, 5, 6));
        System.out.println("result for third 3: "+ob1.add(4.5, 5.3));
        
    }
}
