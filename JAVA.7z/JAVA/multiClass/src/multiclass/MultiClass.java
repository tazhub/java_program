
package multiclass;

public class MultiClass {

    
    public static void main(String[] args) {
        tuna zisLol = new tuna();
        zisLol.mySample();
        
        
    }

  
}
