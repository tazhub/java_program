/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package multiclass;

/**
 *
 * @author Zishan
 */
public class tuna {
     public void mySample(){
        System.out.println("this is a another class");
     }
    
}
